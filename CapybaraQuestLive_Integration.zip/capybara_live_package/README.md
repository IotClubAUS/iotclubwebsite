# Capybara Quest — live multiplayer add-on (Next.js / Vercel)

This is a **new add-on**, not a change to the existing IoT Club website. Your technical team must integrate and deploy it. No online service has been connected by ChatGPT.

## Install

```bash
npm install firebase firebase-admin
```

1. Copy `CapybaraQuestLive.tsx` into your project, e.g. `components/CapybaraQuestLive.tsx`.
2. Add `app/capybara-hunt/page.tsx`:

```tsx
import CapybaraQuestLive from '@/components/CapybaraQuestLive';
export default function Page(){ return <CapybaraQuestLive/> }
```

3. Copy the two `app/api/capybara/.../route.ts` files to the same locations in your Next.js App Router project.
4. Create a Firebase project, enable **Authentication > Anonymous**, create **Cloud Firestore**, and deploy the included `firestore.rules` (Firebase CLI or console).
5. Set these **Vercel environment variables** (also in local `.env.local`):

```
NEXT_PUBLIC_FIREBASE_API_KEY=...
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=...
NEXT_PUBLIC_FIREBASE_PROJECT_ID=...
NEXT_PUBLIC_FIREBASE_APP_ID=...
FIREBASE_SERVICE_ACCOUNT_JSON={...service-account-json...}
CAPYBARA_FINAL_CODE=NOOOO!
CAPYBARA_REOPEN_CODE=IOTCLUB
```

**Never prefix the service account or organizer secrets with `NEXT_PUBLIC_`.** Set them only in Vercel's server-side environment variables. For production, change the reopening code to a stronger secret known only to organizers.

## Behavior

- The original participant game remains embedded inside a TSX React page. The live leaderboard is displayed as an overlay on every mission.
- Each browser profile gets its own Firebase anonymous identity; team progress is written to a team record keyed by that identity. Different devices normally get separate identities. Two tabs in the same browser profile share one identity.
- Team progress and event status are broadcast through Firestore real-time listeners.
- The first team at Mission 8 to submit `NOOOO!` triggers an atomic server-side event end. Everyone online sees the event-ending screen.
- Anyone can *see* the reopen button, but reopening requires the organizer code. Reopening preserves existing team progress and clears the winner; it does not reset the game.

## Important deployment and security notes

- This integration assumes **Next.js App Router**. If the IoT Club site uses Vite or another framework, the API routes must be adapted.
- The legacy puzzle engine is still browser-side. Firebase authentication protects each team's document from other signed-in teams, but a technically sophisticated participant can still manipulate their own stage. For prizes, implement authoritative server-side mission verification and/or volunteer checks before declaring the winner.
- The leaderboard includes team names and current mission. Avoid personal names if participants do not consent to public display.
- Camera access requires HTTPS. The iframe must have `allow="camera"`, and your site's Permissions-Policy must allow camera access.
- The event document can be absent initially; the UI treats it as live. The first winner creates/updates it.
- If you redeploy a new version, users must refresh to get it. Real-time data updates do not require refresh.
- Anonymous identities may be lost if users clear browser storage or use private browsing.
- Firebase free quotas may suffice for a small event but are not guaranteed; monitor usage.
- Existing participants' old local progress is not automatically migrated across devices.
