import {NextRequest,NextResponse} from 'next/server';
import {getApps,initializeApp,cert} from 'firebase-admin/app';
import {getAuth} from 'firebase-admin/auth';
import {getFirestore} from 'firebase-admin/firestore';
function admin(){if(!getApps().length)initializeApp({credential:cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON!))});return {auth:getAuth(),db:getFirestore()}}
export async function POST(req:NextRequest){
 try{
  const {auth,db}=admin();const bearer=req.headers.get('authorization')||'';
  if(!bearer.startsWith('Bearer '))return NextResponse.json({error:'Sign in required'},{status:401});
  await auth.verifyIdToken(bearer.slice(7));
  const {eventId,code}=await req.json();
  if(eventId!=='capybara-quest-2026'||code!==process.env.CAPYBARA_REOPEN_CODE)return NextResponse.json({error:'Incorrect organizer code'},{status:403});
  await db.doc(`events/${eventId}`).set({status:'live',winnerId:null,winnerName:null,reopenedAt:new Date()},{merge:true});
  return NextResponse.json({ok:true});
 }catch(e){return NextResponse.json({error:'Could not reopen event'},{status:500})}
}
