import {NextRequest,NextResponse} from 'next/server';
import {getApps,initializeApp,cert} from 'firebase-admin/app';
import {getAuth} from 'firebase-admin/auth';
import {getFirestore} from 'firebase-admin/firestore';

function admin(){
 if(!getApps().length)initializeApp({credential:cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON!))});
 return {auth:getAuth(),db:getFirestore()};
}
export async function POST(req:NextRequest){
 try{
  const {auth,db}=admin();
  const bearer=req.headers.get('authorization')||'';
  if(!bearer.startsWith('Bearer '))return NextResponse.json({error:'Sign in required'},{status:401});
  const user=await auth.verifyIdToken(bearer.slice(7));
  const {eventId,code}=await req.json();
  if(eventId!=='capybara-quest-2026'||code!==process.env.CAPYBARA_FINAL_CODE)return NextResponse.json({error:'Invalid finish code'},{status:403});
  const eventRef=db.doc(`events/${eventId}`),teamRef=eventRef.collection('teams').doc(user.uid);
  const result=await db.runTransaction(async tx=>{
   const [event,team]=await Promise.all([tx.get(eventRef),tx.get(teamRef)]);
   if(event.data()?.status==='ended')return {error:'The event has already ended'};
   if(!team.exists||Number(team.data()?.stage)!==8)return {error:'Complete Mission 8 first'};
   const name=String(team.data()?.name||'Unnamed team').slice(0,80);
   tx.set(eventRef,{status:'ended',winnerId:user.uid,winnerName:name,endedAt:new Date()},{merge:true});
   tx.set(teamRef,{stage:9,finishedAt:new Date()},{merge:true});
   return {ok:true};
  });
  return result.ok?NextResponse.json(result):NextResponse.json(result,{status:409});
 }catch(e){return NextResponse.json({error:'Unable to verify completion'},{status:500})}
}
